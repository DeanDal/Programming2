/*
 * Author: Pawel Mrozinski
 */
package prog2_coursework;

import java.util.Calendar;
import java.util.Set;

public class Restaurant {
    private int restaurantId;
    private String restaurantName;
    private String restaurantLocation;
    
    private static int numberOfRestaurants=0;
    
    public Restaurant()
    {
        this.restaurantId = 0;
        this.restaurantName = null;
        this.restaurantLocation = null;
        numberOfRestaurants++;
    }	

    public Restaurant(int restaurantId, String restaurantName, String restaurantLocation) {
        this.restaurantId = restaurantId;
        this.restaurantName = restaurantName;
        this.restaurantLocation = restaurantLocation;
        numberOfRestaurants++;
    }

    public void setRestaurantId(int restaurantId) {
        this.restaurantId = restaurantId;
    }
    
    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public void setRestaurantLocation(String restaurantLocation) {
        this.restaurantLocation = restaurantLocation;
    }
    
    public String getRestaurantName() {
        return restaurantName;
    }

    public int getRestaurantId() {
        return restaurantId;
    }

    public String getRestaurantLocation() {
        return restaurantLocation;
    }
    
    public static int getNumberOfRestaurants() {
        return numberOfRestaurants;
    }
    
    @Override
    public String toString() {
        return  "table id: " + getRestaurantId() + ", " +
                "table name: " + getRestaurantName() + ", "+
                "restaurant location: " + getRestaurantLocation();
    }      

    
}
