/*
 * Author: Pawel Mrozinski
 */
package prog2_coursework;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Reservation {
    private int resvnId;
    private Calendar resvnDate;
    public int resvnTime;
    private Customer reservationCustomer;
    private Set<Table> tables;
    
    private static int numberOfReservations=0;  
    
        public Reservation()
        {
        this.resvnId = 0;
        this.resvnDate = null;
        this.resvnTime = 0;
        this.numberOfReservations = 0;
        this.reservationCustomer = null;
        this.tables = new HashSet<>();

        numberOfReservations++;
        }

    public Reservation(int resvnId, Calendar resvnDate, int resvnTime, Customer reservationCustomer, Set<Table> tables) {
        this.resvnId = resvnId;
        this.resvnDate = resvnDate;
        this.resvnTime = resvnTime;
        this.reservationCustomer = reservationCustomer;
        this.tables = tables;
    }
    
    public void setresvnId(int resvnId) {
        this.resvnId = resvnId;
    }

    public void setDate(Calendar Date) {
        this.resvnDate = resvnDate;
    }

    public void setResvnTime(int resvnTime) {
        this.resvnTime = resvnTime;
    }

    public int getResvnId() {
        return resvnId;
    }

    public Calendar getResvnDate() {
        return resvnDate;
    }

    public int getResvnTime() {
        return resvnTime;
    }

    public Customer getReservationCustomer() {
        return reservationCustomer;
    }

    public Set<Table> getTables() {
        return tables;
    }

    public static int getNumberOfReservations() {
        return numberOfReservations;
    }
    
    @Override
    public String toString() {
        return  "reservation id: " + getResvnId() + ", " +
                "reservation date: " + getResvnDate() + ", " +
                "reservation time: " + getResvnTime() + ", " +	
                "reservation customer: " + getReservationCustomer() + ", " +
                "reservation tables: " + getTables();
    }      
    
}
