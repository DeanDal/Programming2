/*
 * Author: Pawel Mrozinski
 */
package prog2_coursework;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import prog2_DAO.DAOFactory;
import prog2_DAO_textdao.TextCustomerDAO;
import prog2_DAO_textdao.TextDAOFactory;
import prog2_DAO_textdao.TextReservationDAO;
import prog2_DAO_textdao.TextRestaurantDAO;
import prog2_DAO_textdao.TextTableDAO;

public class Main {
    static final char DELIMITER='~';
    static String user;
    
        public static void main(String[] args) {
        Scanner userInput = new Scanner (System.in);
        char choice;
        
        //Load all
        List<Customer> customers=loadCustomers(); 
        List<Table> tables=loadTables();   
        List<Restaurant> restaurants=loadRestaurants();
        List<Reservation> reservations=loadReservations(customers, tables);
     
        do
        {
            System.out.println("1. Add New Customer");
            System.out.println("2. Add New Restaurant");            
            System.out.println("3. Add New Reservation");
            System.out.println("4. Delete Customer");
            System.out.println("5. Update Reservation");
            System.out.println("6. List Customers and Reservations");    
            System.out.println("7. List Reservations");  
            System.out.println("8. Load Customers From Textfile");  
            System.out.println("Q. Save and Quit");
            System.out.print("Enter choice: ");
            choice = userInput.next().charAt(0);
            switch(choice)
            {
                
                case '1':
                    System.out.println("Add Customers");
                    customers = addCustomers(customers);
                    break;
                case '2':
                    System.out.println("Add Restaurant");
                    restaurants = addRestaurants(restaurants, tables);
                    break;
                case '3':
                    System.out.println("Add Reservation");
                    reservations = addReservations(reservations, tables, customers);
                    break;    
                case '4':
                    System.out.println("Deleting...");
                    customers = removeCustomer(customers);
                    break;
                case '5':
                    break;
                case '6':
                    System.out.println("List Customers");
                    listCustomers(customers, reservations);
                    break;    
                case '7':
                    System.out.println("List Reservations");
                    listReservations(reservations);                    
                    break;
                case '8':System.out.println("Loading");
                    loadCustomers();
                    break;                    
                case 'Q':
                case 'q': System.out.println("Quitting");
                    userInput.close();
                    break;
                default: System.out.println("Invalid choice: Please re-enter");
            }         
        } while (choice != 'Q' && choice != 'q');
        storeCustomers(customers);
        storeTables(tables);
        storeRestaurants(restaurants);
        storeReservations(reservations);
    }
    
    //Add Customer
    public static List<Customer> addCustomers(List<Customer> customers) {
        int newCustomerId = Customer.getNumberOfCustomers() + 1;
        String customerName= readString("Enter New Customer Name");
        String customerPhone = readString("Enter new customer Phone");
        String customerEmail = readString("Enter new customer email");
        String customerContact = readString("Enter new customer contact");
    	
    	Customer c = new Customer(newCustomerId, customerName, customerPhone, customerEmail, customerContact);
    	
        customers.add(c);   
        
        return customers;
    }
    
    //Load Customers
    public static List<Customer> loadCustomers() {
        List<Customer> customers;
        Path path=Paths.get("customers.txt");
    	
        TextDAOFactory daoFactory = (TextDAOFactory) DAOFactory.getDAOFactory(1);
        TextCustomerDAO dao = (TextCustomerDAO) daoFactory.getCustomerDAO();
        customers = dao.loadCustomers(path);   
        
        return customers;
    }
    
    //Remove Customer
    public static List<Customer> removeCustomer(List <Customer> customers) {
        customers.remove(customers.size() - 1);
        return customers;
    }
    
    //Store Customer
    public static void storeCustomers(List<Customer> customers) {
        Path path=Paths.get("newcustomers.txt");
    	
        TextDAOFactory daoFactory = (TextDAOFactory) DAOFactory.getDAOFactory(1);
        TextCustomerDAO dao = (TextCustomerDAO) daoFactory.getCustomerDAO();
        dao.storeCustomers(path, customers);   
    }    
    
    //Store Tables
        public static void storeTables(List<Table> tables) {
        Path path=Paths.get("newtables.txt");
    	
        TextDAOFactory daoFactory = (TextDAOFactory) DAOFactory.getDAOFactory(1);
        TextTableDAO dao = (TextTableDAO) daoFactory.getTableDAO();
        dao.storeTables(path, tables);   
    }    
    
    //Store Restaurants
        public static void storeRestaurants(List<Restaurant> restaurants) {
        Path path=Paths.get("newrestaurants.txt");
    	
        TextDAOFactory daoFactory = (TextDAOFactory) DAOFactory.getDAOFactory(1);
        TextRestaurantDAO dao = (TextRestaurantDAO) daoFactory.getRestaurantDAO();
        dao.storeRestaurants(path, restaurants);   
    }    
    
    //Load Tables from File
    public static List<Table> loadTables() {
        List<Table> tables;
        Path path=Paths.get("tables.txt");
    	
        TextDAOFactory daoFactory = (TextDAOFactory) DAOFactory.getDAOFactory(1);
        TextTableDAO dao = (TextTableDAO) daoFactory.getTableDAO();
        tables = dao.loadTables(path);   
        
        return tables;
    }    

    //Load Restaurants from File
    public static List<Restaurant> loadRestaurants() {
        List<Restaurant> restaurants;
        Path path=Paths.get("restaurants.txt");
    	
        TextDAOFactory daoFactory = (TextDAOFactory) DAOFactory.getDAOFactory(1);
        TextRestaurantDAO dao = (TextRestaurantDAO) daoFactory.getRestaurantDAO();
        restaurants = dao.loadRestaurants(path);   
        
        return restaurants;
    }    
    
    //Add Restaurant
    public static List addRestaurants(List<Restaurant> restaurants, List<Table> tables) {
        Path path=Paths.get("newrestaurants.txt");
     
        TextDAOFactory daoFactory = (TextDAOFactory) DAOFactory.getDAOFactory(1);
        TextRestaurantDAO dao = (TextRestaurantDAO) daoFactory.getRestaurantDAO();
        dao.storeRestaurants(path, restaurants);   
        
        int newRestaurantId = Restaurant.getNumberOfRestaurants() + 1;
        String restaurantName = readString("Enter Restaurant Name");
        String restaurantLocation = readString("Enter Restaurant Location");
        int table = readInt("Enter number of tables in restaurant");
        
        //Loop for adding tables, asks for no. of seats each time
        for(int i=1; i<(table+1); i++) {
            addTables(tables);
        }
        
        Restaurant r = new Restaurant(newRestaurantId, restaurantName, restaurantLocation);
        restaurants.add(r);
        
        return restaurants;
    }
    
    //Add tables and seats, loops in 'Add Restaurant'
    public static List<Table> addTables(List<Table> tables) {

        int newTableId = Table.getNumberOfTables() + 1;
        int tableSeats= readInt("Enter Number of Seats");

        {
            Table e = new Table(newTableId, tableSeats);
            tables.add(e);               
        }
        
        return tables;
    }
    
    //Load Reservations with customers and tables
    public static List<Reservation> loadReservations(List<Customer> customers, List<Table> tables) {
        List<Reservation> reservations;
        Path path=Paths.get("reservations.txt");
    	
        TextDAOFactory daoFactory = (TextDAOFactory) DAOFactory.getDAOFactory(1);
        TextReservationDAO dao = (TextReservationDAO) daoFactory.getReservationDAO();
        reservations = dao.loadReservations(path, customers, tables);   
        
        reservations.stream().forEach((p) -> {
            p.getTables().stream().forEach((pe) -> {
                tables.stream().filter((e) -> (e.getTableId() == pe.getTableId())).forEach((e) -> {
                    e.addReservation(p);
                });
            });
        });
        
        return reservations;
    } 
    
    //Add reservations with all details, customers and tables
    public static List<Reservation> addReservations(List<Reservation> reservations, List<Table> tables, List<Customer> customers) {
    	int newReservationId = Reservation.getNumberOfReservations() + 1;
        
        //Date from calendar
        String startString = readString("Enter start date [yyyy/mm/dd]");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Date date = null;
        try {
            date = sdf.parse(startString);
        } catch (ParseException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        Calendar startDate = Calendar.getInstance();
        startDate.setTime(date);
        
        int resvnSlot = readInt("Enter Reservation Hour");

        listCustomers(customers, reservations);
        int reservationCustomerId = readInt("Enter Project Customer Id");
    	Customer reservationCustomer = customers.get(reservationCustomerId-1);
    	
        HashSet<Table> reservationTables = new HashSet<>();
    	listTables(tables);
        int reservationTableId;
    	do {
            reservationTableId = readInt("Enter Reservation Table Id (0 to finish)");
            if (reservationTableId != 0) {
                Table e = tables.get(reservationTableId-1); 
                reservationTables.add(e);
            }            
        } while (reservationTableId !=0);
    	
        //Create new reservation with details, customer and table
    	Reservation p = new Reservation(newReservationId, startDate, resvnSlot, reservationCustomer, reservationTables);              
        reservations.add(p);
        
        for (Table e : reservationTables) {
            e.addReservation(p);
        }    
        
        return reservations;
    }    
    
    //List customers
    public static void listCustomers(List<Customer> customers, List<Reservation> reservations) {  
        System.out.format("\033[31m%s\033[0m%n", "Customers");
        System.out.format("\033[31m%s\033[0m%n", "=========");
        for (Customer c : customers) {
            System.out.format("\033[33m%s\033[0m%n", "Customer"); 
            System.out.format("\033[33m%s\033[0m%n", "--------"); 
            System.out.println(c);
            System.out.format("\033[32m%s\033[0m%n", "Reservations");          
            listCustomerReservations(c, reservations);
        }    	
    }
    
    //Store reservations
    public static void storeReservations(List<Reservation> reservations) {
        Path path=Paths.get("newreservations.txt");
    	
        TextDAOFactory daoFactory = (TextDAOFactory) DAOFactory.getDAOFactory(1);
        TextReservationDAO dao = (TextReservationDAO) daoFactory.getReservationDAO();
        dao.storeReservations(path, reservations);   
    }    
    
    //Store reservations only
    public static void listReservations(List<Reservation> reservations) {        
        System.out.format("\033[31m%s\033[0m%n", "Reservations");
        System.out.format("\033[31m%s\033[0m%n", "========");
        for (Reservation p : reservations) {
            System.out.format("\033[33m%s\033[0m%n", "Reservation"); 
            System.out.format("\033[33m%s\033[0m%n", "-------");             
            System.out.println(p);
        }    	
    }
    
    //Store customer's reservations
    public static void listCustomerReservations(Customer c, List<Reservation> reservations) {        
        for (Reservation p : reservations) {
            if (p.getReservationCustomer() == c)
                System.out.println(p);
        }    	
    }    
    
    //list tables
    public static void listTables(List<Table> tables) {        
        System.out.format("\033[31m%s\033[0m%n", "Tables");
        System.out.format("\033[31m%s\033[0m%n", "=========");
        for (Table e : tables) {
            System.out.format("\033[33m%s\033[0m%n", "Table"); 
            System.out.format("\033[33m%s\033[0m%n", "--------");             
            System.out.println(e);
            System.out.format("\033[32m%s\033[0m%n", "Reservations");               
            listReservations(new ArrayList(e.getReservations()));
        }    	
    }    
    
    // Read String - IMPORTANT
    public static String readString(String prompt) {
        Scanner input = new Scanner(System.in);
        
        System.out.print(prompt + ": ");
        String inputText = input.nextLine();
        return inputText;
    }
    
// Read Int - IMPORTANT
    public static int readInt(String prompt) {
        Scanner input = new Scanner(System.in);
            
        System.out.print(prompt + ": ");
        int inputNumber = input.nextInt();
        return inputNumber;
    }
}