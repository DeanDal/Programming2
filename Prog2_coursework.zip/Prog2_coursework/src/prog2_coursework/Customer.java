/*
 * Author: Pawel Mrozinski
 */
package prog2_coursework;

public class Customer {
    private int customerId;
    private String customerName;
    private String customerPhone;
    private String customerEmail;
    private String customerContact;
    
    private static int numberOfCustomers=0;
    
    public Customer()
    {
        this.customerId = 0;
        this.customerName = null;
        this.customerPhone = null;
        this.customerEmail = null;
        this.customerContact = null;
        numberOfCustomers++;
    }	

    public Customer(int customerId, String customerName, String customerPhone, String customerEmail, String customerContact) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerPhone = customerPhone;
        this.customerEmail = customerEmail;
        this.customerContact = customerContact;
        numberOfCustomers++;
    }

    public static int getNumberOfCustomers() {
        return numberOfCustomers;
    }
    
    public void setId(int customerId) {
        this.customerId = ++customerId;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public void setCustomerContact(String customerContact) {
        this.customerContact = customerContact;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public String getCustomerContact() {
        return customerContact;
    }
    
    @Override
    public String toString() {
        return  "customer id: " + getCustomerId() + ", " +
                "customer name: " + getCustomerName() + ", " +
                "customer address: " + getCustomerPhone() + ", " +	
                "customer email: " + getCustomerEmail() + ", " +
                "customer contact: " + getCustomerContact(); 
    }      
}