/*
 * Author: Pawel Mrozinski
 */
package prog2_coursework;

import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author mga
 */
public class Table {
    protected int tableId;
    protected int tableSeats;
    protected Set<Reservation> reservations;    
    
    private static int numberOfTables=0;    

    public Table()
    {
        this.tableId = 0;
        this.tableSeats = 0;
        this.reservations = new HashSet<>();
        numberOfTables++;
    }	
	
    public Table(int tableId, int tableSeats)
    {
        this.tableId = tableId;
        this.tableSeats = tableSeats;
        this.reservations = new HashSet<>();
        numberOfTables++;
    }
    
    public Table(int tableId, String tableName, Set<Reservation> reservations)
    {
        this.tableId = tableId;
        this.tableSeats = tableSeats;
        this.reservations = reservations;
        numberOfTables++;
    }

    public static int getNumberOfTables() {
        return numberOfTables;
    }    
    
    public int getTableId()
    {
        return this.tableId;
    }    
    
    public void setTableId(int tableId)
    {
        this.tableId = tableId;
    }      
    
    public int getTableSeats()
    {
        return this.tableSeats;
    }     
    
    public void setTableSeats(int tableSeats)
    {
        this.tableSeats = tableSeats;
    }           
    
    public Set<Reservation> getReservations()
    {
        return this.reservations;
    }

    public void setReservations(Set<Reservation> reservations)
    {
        this.reservations = reservations;
    }  
    
    public void addReservation(Reservation reservation)
    {
        this.reservations.add(reservation);
    }
    
    @Override
    public String toString() {
        return  "table id: " + getTableId() + ", " +
                "table seats: " + getTableSeats() + ", ";	
    }      
}

