/*
 * Author: Pawel Mrozinski
 */
package prog2_DAO;

import prog2_DAO_textdao.TextDAOFactory;

    public abstract class DAOFactory {

	// List of DAO types supported by the factory
	public static final int TEXT = 1;            
	public static final int OBJECT = 2;          
	public static final int RDB = 3;
	public static final int XML = 4;
	public static final int OODB = 5;
	public static final int NOSQL = 6;      


        // There will be a method for each DAO that can be 
        // created. The concrete factories will have to 
        // implement these methods.
        public abstract CustomerDAO getCustomerDAO();
        public abstract TableDAO getTableDAO();
        public abstract RestaurantDAO getRestaurantDAO();
        public abstract ReservationDAO getReservationDAO();        

        public static DAOFactory getDAOFactory(int whichFactory) {
            switch (whichFactory) {
                case TEXT:
                    return new TextDAOFactory();
                //case OBJECT:
                //    return new ObjectDAOFactory();
                default: 
                    return null;
            }
        }
    }
