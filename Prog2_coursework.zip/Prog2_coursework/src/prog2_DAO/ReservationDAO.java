/*
 * Author: Pawel Mrozinski
 */
package prog2_DAO;

import java.nio.file.Path;
import java.util.List;
import prog2_coursework.Customer;
import prog2_coursework.Table;
import prog2_coursework.Reservation;

public abstract class ReservationDAO {

    public abstract List<Reservation> loadReservations(Path path, List<Customer> customers, List<Table> tables);

    public abstract void storeReservation(Path path, List<Reservation> reservations);
    
}
