/*
 * Author: Pawel Mrozinski
 */
package prog2_DAO;

import java.nio.file.Path;
import java.util.List;
import prog2_coursework.Table;

public abstract class TableDAO {

    public abstract List<Table> loadTables(Path path);

    public abstract void storeTables(Path path, List<Table> tables);
    
}
