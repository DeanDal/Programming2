/*
 * Author: Pawel Mrozinski
 */
package prog2_DAO;

import java.nio.file.Path;
import java.util.List;
import prog2_coursework.Customer;

public abstract class CustomerDAO {

    public abstract List<Customer> loadCustomers(Path path);

    public abstract void storeCustomers(Path path, List<Customer> customers);
    
}
