/*
 * Author: Pawel Mrozinski
 */
package prog2_DAO;

import java.nio.file.Path;
import java.util.List;
import prog2_coursework.Restaurant;

public abstract class RestaurantDAO {

    public abstract List<Restaurant> loadRestaurants(Path path);

    public abstract void storeRestaurants(Path path, List<Restaurant> restaurantss);
    
}
