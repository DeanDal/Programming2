/*
 * Author: Pawel Mrozinski
 */
package prog2_DAO_textdao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import prog2_coursework.Customer;
import prog2_DAO.CustomerDAO;

public class TextCustomerDAO extends CustomerDAO {
    static final char DELIMITER=':';
    
    @Override
    public List<Customer> loadCustomers(Path path) {
        List<Customer> customers = new ArrayList<>();   
        try (Scanner s = new Scanner(new BufferedReader(new FileReader(path.toString())))) {         
            s.useDelimiter(Character.toString(DELIMITER));
            Customer c;
            int customerID;
            String customerName, customerPhone, customerEmail, customerContact;
            
            while (s.hasNext()) {
                if (s.hasNextInt()) {
                    customerID = s.nextInt();
                }
                else {
                    customerID = 0;
                }
                customerName = s.next();
                customerPhone = s.next();
                customerEmail = s.next();
                customerContact = s.next();
                s.nextLine();
                c = new Customer(customerID, customerName, customerPhone, customerEmail, customerContact);
                customers.add(c);
            }
            s.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(TextCustomerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }        
        return customers;
    }
    
    @Override
    public void storeCustomers(Path path, List<Customer> customers) {
        try (PrintWriter output = new PrintWriter(path.toFile())) {
            for (Customer c:customers) {
                output.println(toFileString(c));
            }
            output.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(TextCustomerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    public String toFileString(Customer c) {
        return  Integer.toString(c.getCustomerId()) + DELIMITER +
                c.getCustomerName() + DELIMITER +
                c.getCustomerPhone() + DELIMITER +
                c.getCustomerEmail() + DELIMITER +
                c.getCustomerContact() + DELIMITER;
    }    
    
}
