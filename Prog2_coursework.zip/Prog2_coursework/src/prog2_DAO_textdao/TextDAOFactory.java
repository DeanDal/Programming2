/*
 * Author: Pawel Mrozinski
 */
package prog2_DAO_textdao;

import java.util.logging.Level;
import java.util.logging.Logger;
import prog2_DAO.CustomerDAO;
import prog2_DAO.TableDAO;
import prog2_DAO.DAOFactory;
import prog2_DAO.RestaurantDAO;
import prog2_DAO.ReservationDAO;

public class TextDAOFactory extends DAOFactory {

    @Override
    public CustomerDAO getCustomerDAO() {
        try {
            return (TextCustomerDAO) createDAO(TextCustomerDAO.class);
        } catch (InstantiationException | IllegalAccessException ex) {
            Logger.getLogger(TextDAOFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public TableDAO getTableDAO() {
        try {
            return (TextTableDAO) createDAO(TextTableDAO.class);
        } catch (InstantiationException | IllegalAccessException ex) {
            Logger.getLogger(TextDAOFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public ReservationDAO getReservationDAO() {
        try {
            return (TextReservationDAO) createDAO(TextReservationDAO.class);
        } catch (InstantiationException | IllegalAccessException ex) {
            Logger.getLogger(TextDAOFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    private Object createDAO(Class classObj) throws InstantiationException, IllegalAccessException {
        return classObj.newInstance();
    }

    @Override
    public RestaurantDAO getRestaurantDAO() {
        try {
            return (TextRestaurantDAO) createDAO(TextRestaurantDAO.class);
        } catch (InstantiationException | IllegalAccessException ex) {
            Logger.getLogger(TextDAOFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}