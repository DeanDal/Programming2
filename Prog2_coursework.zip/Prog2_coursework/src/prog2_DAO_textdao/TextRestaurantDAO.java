/*
 * Author: Pawel Mrozinski
 */
package prog2_DAO_textdao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import prog2_coursework.Restaurant;
import prog2_DAO.RestaurantDAO;

public class TextRestaurantDAO extends RestaurantDAO {
    static final char DELIMITER=':';
    
    @Override
    public List<Restaurant> loadRestaurants(Path path) {
        List<Restaurant> restaurants = new ArrayList<>();  
        try (BufferedReader br = new BufferedReader(new FileReader(path.toString()))) {         
            Restaurant e = null;
            String restaurantName;
            String restaurantLocation;
            
            String[] temp;
            String line = br.readLine();

            while(line!=null){
                temp=line.split(Character.toString(DELIMITER));
                restaurantName = temp[1];
                restaurantLocation = temp[2];

                {
                    Restaurant c = null;
                    restaurants.add(c);
                }
                line = br.readLine();
            }  
            br.close();
        } catch (IOException ex) {
            Logger.getLogger(TextRestaurantDAO.class.getName()).log(Level.SEVERE, null, ex);
        }               
        return restaurants;
    }
    
    @Override
    public void storeRestaurants(Path path, List<Restaurant> restaurants) {
        try (PrintWriter output = new PrintWriter(path.toFile())) {
            for (Restaurant e : restaurants) {
                output.println(toFileString(e));
            }
            output.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(TextRestaurantDAO.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    private String toFileString(Restaurant e) {
        return  Integer.toString(e.getRestaurantId()) + DELIMITER +
                e.getRestaurantName() + DELIMITER +
                e.getRestaurantLocation() + DELIMITER;
    }    
    
}
