/*
 * Author: Pawel Mrozinski
 */
package prog2_DAO_textdao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import prog2_coursework.Table;
import prog2_DAO.TableDAO;

public class TextTableDAO extends TableDAO {
    static final char DELIMITER=':';
    
    @Override
    public List<Table> loadTables(Path path) {
        List<Table> tables = new ArrayList<>();  
        try (BufferedReader br = new BufferedReader(new FileReader(path.toString()))) {         
            Table e = null;
            int tableId;
            String tableName;
            
            String[] temp;
            String line = br.readLine();

            while(line!=null){
                temp=line.split(Character.toString(DELIMITER));
                tableId = Integer.parseInt(temp[0]);
                tableName = temp[1];

                {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
                    String dateInString = temp[2];
                    Date date = null;
                    try {
                        date = sdf.parse(dateInString);
                    } catch (ParseException ex) {
                        Logger.getLogger(TextTableDAO.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    Table c = null;
                    tables.add(c);
                }
                line = br.readLine();
            }  
            br.close();
        } catch (IOException ex) {
            Logger.getLogger(TextTableDAO.class.getName()).log(Level.SEVERE, null, ex);
        }               
        return tables;
    }
    
    @Override
    public void storeTables(Path path, List<Table> tables) {
        try (PrintWriter output = new PrintWriter(path.toFile())) {
            for (Table e : tables) {
                output.println(toFileString(e));
            }
            output.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(TextTableDAO.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    private String toFileString(Table e) {
        return  Integer.toString(e.getTableId()) + DELIMITER +
                e.getTableSeats() + DELIMITER;
    }    
    
}
