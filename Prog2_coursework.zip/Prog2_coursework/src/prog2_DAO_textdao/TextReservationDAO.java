/*
 * Author: Pawel Mrozinski
 */
package prog2_DAO_textdao;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Path;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import prog2_coursework.Customer;
import prog2_coursework.Table;
import prog2_coursework.Reservation;
import prog2_DAO.ReservationDAO;

public class TextReservationDAO extends ReservationDAO {
    static final char DELIMITER=':';
    
    @Override
    public List<Reservation> loadReservations(Path path, List<Customer> customers, List<Table> tables) {
        List<Reservation> reservations = new ArrayList<>();   
        

        try (BufferedReader br = new BufferedReader(new FileReader(path.toString()))) {         
            int resvnId, customerId, numberOfTables, tableId, resvnSlot;
           
            
            String[] temp;
            String line = br.readLine();

            while(line!=null){
                Customer reservationCustomer=null;
                HashSet<Table> reservationTables=new HashSet<>(); 
                temp=line.split(Character.toString(DELIMITER));
                resvnId = Integer.parseInt(temp[0]);
                customerId = Integer.parseInt(temp[1]);
                numberOfTables = Integer.parseInt(temp[2]);
                tableId = Integer.parseInt(temp[3]);
                resvnSlot = Integer.parseInt(temp[4]);

                Calendar resvnDate = null;
                
                for (Customer c:customers) {
                    if (c.getCustomerId() == customerId)
                        reservationCustomer = c;
                }
                numberOfTables = Integer.parseInt(temp[6]);
                for (int i=6; i<temp.length; i++) {
                    tableId = Integer.parseInt(temp[i]);
                    for (Table t:tables) {
                        if (t.getTableId() == tableId)
                            reservationTables.add(t);
                    }
                }
                line = br.readLine();
                Reservation p = new Reservation(resvnId, resvnDate, resvnSlot, reservationCustomer, (Set<Table>) tables);
                reservations.add(p);
            }  
            br.close();
        } catch (IOException ex) {
            Logger.getLogger(TextTableDAO.class.getName()).log(Level.SEVERE, null, ex);
        }        
        return reservations;
    }
    
    public void storeReservations(Path path, List<Reservation> reservations) {
        try (PrintWriter output = new PrintWriter(path.toFile())) {
            reservations.stream().forEach((p) -> {
                output.println(toFileString(p));
            });
            output.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(TextReservationDAO.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
    
    private String toFileString(Reservation p) {
        String s = 
                Integer.toString(p.getResvnId()) + DELIMITER +
                p.getResvnDate() + DELIMITER +                
                Integer.toString(p.getReservationCustomer().getCustomerId()) + DELIMITER +
                Integer.toString(p.getTables().size()) + DELIMITER;
        s = p.getTables().stream().map((e) -> Integer.toString(e.getTableId()) + DELIMITER).reduce(s, String::concat);
        return s;
    }    

    @Override
    public void storeReservation(Path path, List<Reservation> reservations) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}